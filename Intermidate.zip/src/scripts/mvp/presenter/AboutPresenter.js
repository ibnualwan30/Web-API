// src/scripts/mvp/presenter/AboutPresenter.js

export default class AboutPresenter {
    constructor({ view }) {
      this._view = view;
    }
    
  }