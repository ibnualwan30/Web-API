// src/scripts/mvp/view/about-view.js

export default class AboutView {
    constructor() {
      // Tidak ada logika khusus untuk halaman About
    }
  }